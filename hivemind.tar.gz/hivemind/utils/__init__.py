"""工具函数"""

from .data import load_json_data, create_sample_dataset

__all__ = ["load_json_data", "create_sample_dataset"]
