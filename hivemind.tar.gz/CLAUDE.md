# HiveMind - 蜂巢智慧 AI

> 一个可自我进化、个性化学习的分布式 AI 系统

## 项目愿景

HiveMind 让每个用户拥有独特的个性化 AI，同时通过联邦学习将所有用户的智慧汇聚，持续进化出更强大的基础模型。

## 核心架构

```
用户端 (Client)                          服务端 (Server)
┌─────────────────┐                    ┌─────────────────┐
│  Base Model     │                    │  Aggregator     │
│  (Qwen2-7B)     │                    │  (FedAvg)       │
│       +         │   ──上传 LoRA──►   │                 │
│  Personal LoRA  │                    │  Model Storage  │
│  Adapter        │   ◄──下载更新──    │                 │
└─────────────────┘                    └─────────────────┘
```

## 技术栈

| 组件 | 技术选型 | 说明 |
|------|----------|------|
| 基础模型 | Qwen2-7B | 开源、中文友好、性能优秀 |
| 微调方法 | LoRA/QLoRA (PEFT) | 低资源消耗，adapter 体积小 |
| 推理引擎 | Transformers / vLLM | 本地推理 |
| 服务框架 | FastAPI | 高性能异步 API |
| 聚合算法 | FedAvg | 联邦平均，后续可扩展 |
| 数据格式 | Alpaca / ShareGPT | 对话训练数据格式 |

## 目录结构

```
HiveMind/
├── CLAUDE.md              # 本文件 - 项目规范
├── pyproject.toml         # Python 项目配置
├── requirements.txt       # 依赖清单
│
├── hivemind/              # 核心代码
│   ├── __init__.py
│   ├── config.py          # 全局配置
│   │
│   ├── server/            # 服务端模块
│   │   ├── app.py         # FastAPI 主应用
│   │   ├── aggregator.py  # LoRA 聚合逻辑
│   │   └── storage.py     # Adapter 存储管理
│   │
│   ├── client/            # 客户端模块
│   │   ├── trainer.py     # 本地 LoRA 训练
│   │   ├── inference.py   # 本地推理
│   │   └── uploader.py    # Adapter 上传
│   │
│   ├── models/            # 模型相关
│   │   ├── base.py        # 基础模型加载
│   │   └── lora.py        # LoRA 配置与工具
│   │
│   └── utils/             # 工具函数
│       └── data.py        # 数据处理
│
├── scripts/               # 脚本
│   ├── train.py           # 训练入口
│   ├── serve.py           # 启动服务
│   └── chat.py            # 交互对话
│
├── data/                  # 训练数据目录
├── adapters/              # LoRA adapter 存储
└── tests/                 # 测试
```

## 开发规范

### 代码风格

- Python 3.10+
- 使用 type hints
- 遵循 PEP 8
- 使用 `ruff` 进行 lint
- 使用 `black` 格式化代码

### 命名约定

- 文件名: `snake_case.py`
- 类名: `PascalCase`
- 函数/变量: `snake_case`
- 常量: `UPPER_SNAKE_CASE`

### 模块职责

#### `hivemind.client.trainer`
- 加载本地数据集
- 配置 LoRA 参数
- 执行微调训练
- 保存 adapter 权重

#### `hivemind.client.inference`
- 加载基础模型 + LoRA
- 提供对话接口
- 支持流式输出

#### `hivemind.server.aggregator`
- 接收多个用户的 LoRA adapter
- 执行 FedAvg 聚合
- 生成进化后的模型权重

#### `hivemind.server.storage`
- 管理 adapter 版本
- 存储聚合后的模型
- 提供下载接口

## 数据格式

### 训练数据 (Alpaca 格式)

```json
[
  {
    "instruction": "用户的问题或指令",
    "input": "可选的额外输入",
    "output": "期望的回答"
  }
]
```

### LoRA Adapter 元数据

```json
{
  "user_id": "unique_user_id",
  "base_model": "Qwen/Qwen2-7B",
  "lora_config": {
    "r": 16,
    "lora_alpha": 32,
    "target_modules": ["q_proj", "v_proj"]
  },
  "training_info": {
    "epochs": 3,
    "samples": 1000,
    "timestamp": "2024-01-01T00:00:00Z"
  },
  "version": "1.0.0"
}
```

## API 接口

### 服务端 API

| 端点 | 方法 | 说明 |
|------|------|------|
| `/api/v1/adapter/upload` | POST | 上传 LoRA adapter |
| `/api/v1/adapter/download/{version}` | GET | 下载聚合后的 adapter |
| `/api/v1/model/status` | GET | 查看当前模型状态 |
| `/api/v1/aggregate/trigger` | POST | 触发聚合 (管理员) |

## 配置项

```python
# config.py 中的关键配置

# 模型配置
BASE_MODEL = "Qwen/Qwen2-7B"
MODEL_CACHE_DIR = "./models"

# LoRA 配置
LORA_R = 16
LORA_ALPHA = 32
LORA_DROPOUT = 0.05
TARGET_MODULES = ["q_proj", "k_proj", "v_proj", "o_proj"]

# 训练配置
BATCH_SIZE = 4
GRADIENT_ACCUMULATION_STEPS = 4
LEARNING_RATE = 2e-4
NUM_EPOCHS = 3

# 服务配置
SERVER_HOST = "0.0.0.0"
SERVER_PORT = 8000
```

## 开发流程

### MVP 阶段目标

1. **本地训练**: 用户可用自己的对话数据训练 LoRA
2. **本地推理**: 加载基础模型 + LoRA 进行对话
3. **上传 Adapter**: 将训练好的 LoRA 上传到服务器
4. **简单聚合**: 服务端执行 FedAvg 聚合多个 adapter
5. **下载更新**: 用户下载聚合后的 adapter

### 启动命令

```bash
# 安装依赖
pip install -e .

# 本地训练
python scripts/train.py --data ./data/my_conversations.json

# 启动对话
python scripts/chat.py

# 上传 adapter
python scripts/upload.py --server http://localhost:8000

# 启动服务端
python scripts/serve.py
```

## 注意事项

- 首次运行会下载 Qwen2-7B 模型 (~14GB)
- 训练需要至少 16GB 显存 (使用 QLoRA 可降至 8GB)
- CPU 训练可行但速度较慢
- adapter 文件约 50-100MB

## 后续扩展

- [ ] 差分隐私保护
- [ ] Byzantine-robust 聚合算法
- [ ] 模型量化 (INT4/INT8)
- [ ] Web UI 界面
- [ ] 持续学习防遗忘机制
